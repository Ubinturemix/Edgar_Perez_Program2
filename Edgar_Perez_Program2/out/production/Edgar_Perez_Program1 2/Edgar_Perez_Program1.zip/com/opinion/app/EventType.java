/*
Author: Edgar Perez
Assignment: Program 2
Class: CSC 2040
 */


package com.opinion.app;

//Types of datastore events observers can recieve
public enum EventType {

    ADD_USER,
    UPDATE_USER,
    ADD_USER_REVIEW,
    ADD_REVIEW_APPROVAL

}
